import {GLTFLoader} from ",/libs/GLTFLoader.js"
const THREE = window.MINDAR.IMAGE.THREE;
